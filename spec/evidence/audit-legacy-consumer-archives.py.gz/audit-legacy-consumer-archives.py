import hashlib,json,subprocess,zipfile
from pathlib import Path
root=Path.cwd()
revision=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip()
profiles=['armor-bobwarfare-f200-2077.json','py-coal-f200-2077.json','py-alienlife-hightech-f200-2077.json','bob-core-f210-2123.json','materials-k2so-f210.json']
tokens=[b'more-infinite-research-browser',b'more-infinite-research-settings',b'MIR4ApiResponseV1',b'mir4_api_v1',b'MIR4MEPEnvelopeV1',b'more-infinite-research-compatibility-pack']
def sha(data):return hashlib.sha256(data).hexdigest().upper()
selected={};rows=[];inputs=[];total=0
for name in profiles:
 path='tests/mir5/profiles/'+name
 raw=subprocess.check_output(['git','show',revision+':'+path]);p=json.loads(raw)
 inputs.append({'path':path,'git_content_sha256':sha(raw),'factorio_line':p['factorio_line']})
 for archive,digest in p['archive_sha256'].items():
  if archive.startswith('mir-fixture-'):continue
  key=(p['factorio_line'],archive)
  if key in selected and selected[key]!=digest.upper():raise ValueError('conflicting archive pin')
  selected[key]=digest.upper()
for (line,name),expected in sorted(selected.items()):
 path=Path('D:/Projects/Factorio/testmods')/line/name
 with path.open('rb') as f:actual=hashlib.file_digest(f,'sha256').hexdigest().upper()
 if actual!=expected:raise ValueError('archive hash mismatch: '+name)
 count=size=0;hits=[]
 with zipfile.ZipFile(path) as archive:
  for entry in archive.infolist():
   if entry.is_dir() or Path(entry.filename).suffix.lower() not in {'.lua','.json','.cfg','.txt','.md','.yml','.yaml','.py','.ps1','.js','.ts'}:continue
   if entry.file_size>8*1024*1024:raise ValueError('bounded member limit: '+name+'/'+entry.filename)
   total+=entry.file_size
   if total>256*1024*1024:raise ValueError('bounded total text limit')
   content=archive.read(entry)
   count+=1;size+=len(content)
   found=[token.decode() for token in tokens if token in content]
   if found:hits.append({'member':entry.filename,'sha256':sha(content),'matched_literals':found})
 rows.append({'factorio_line':line,'archive':name,'archive_sha256':actual,'text_members_scanned':count,'text_bytes_scanned':size,'hits':hits})
result={'schema':1,'kind':'MIR5AvailableIntegrationLegacyConsumerAuditV1','source_commit':revision,'profiles':inputs,'exact_literals':[t.decode() for t in tokens],'archive_count':len(rows),'text_members_scanned':sum(r['text_members_scanned'] for r in rows),'text_bytes_scanned':total,'archives':rows,'limits':{'member_bytes':8*1024*1024,'total_text_bytes':256*1024*1024},'scope':'Read-only exact-literal audit of hash-verified archives selected by five dependency-valid profiles. No extraction, installation, archive mutation or Factorio execution. This is not an exhaustive external-consumer census; computed/dynamic interface names, other archives/versions and other machines are outside the search.','native_execution':False,'release_qualification':False}
output=root/'build/mir5/recovery/api-consumer-archive-audit-cd80371e.json'
output.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'output':str(output),'sha256':sha(output.read_bytes()),'archives':len(rows),'text_members':result['text_members_scanned'],'text_bytes':total,'matched_archives':[{'archive':r['archive'],'hits':r['hits']} for r in rows if r['hits']]}))
