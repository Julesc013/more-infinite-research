"""Derive the Armor/Py F200 expected world from verified reference captures only.

This package-excluded evidence helper reads the independent upstream and
published-4.7 arms of one verified worker artifact.  It uses committed modern
catalogue recovery primitives, retains raw receipt identities, and does not
read a MIR5 candidate.  The exact F200 captures have no usable optional
maximum-level-policy record, so that unrelated field is deliberately omitted
from this comparison-only scratch object.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys


PROFILES = ("armor-bobwarfare", "py-coal", "py-alienlife-hightech")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def recover_profile(catalogue, identifier: str, upstream_root: Path, published_root: Path) -> dict:
    upstream = catalogue.read_capture(upstream_root, require_mir=False)
    published = catalogue.read_capture(published_root, require_mir=True)
    if published["published_mir"]["version"] != "4.7.20002":
        raise ValueError("published reference is not the exact 4.7.20002 archive")
    for field in ("engine", "selection", "loaded", "profile"):
        if upstream[field] != published[field]:
            raise ValueError(f"{identifier} reference arms differ: {field}")

    def identities(rows: list[dict]) -> set[tuple[str, str, str, bool]]:
        values = {(row["name"], row["version"], row["sha256"], row["builtin"]) for row in rows}
        if len(values) != len(rows):
            raise ValueError(f"{identifier} reference archive identities are not unique")
        return values

    if identities(upstream["selected"]) != identities(published["selected"]):
        raise ValueError(f"{identifier} reference archive identities differ")

    data = catalogue._diff_domain(upstream["raw"], published["raw"], f"{identifier} data")
    settings = catalogue._diff_domain(upstream["settings"], published["settings"], f"{identifier} settings")
    generated = [record for record in data["additions"] if record["type"] == "technology"]
    return {
        "id": identifier,
        "capture_receipts": {
            "no_mir": catalogue._capture_receipt(upstream),
            "published_470": catalogue._capture_receipt(published),
        },
        "published_output": {"data": data, "settings": settings},
        "intended_player_output": {
            "data": catalogue._intended_data(data),
            "settings": catalogue._intended_settings(settings),
        },
        "normal_patterns": catalogue._normal_patterns(data, settings),
        "special_cases": {
            "native_continuations": [
                record for record in generated
                if catalogue._technology_group(record["row"]) == "native-continuations"
            ],
            "foreign_prototype_patches": data["patches"],
            "published_private_mir4_metadata": catalogue._private_metadata(data["additions"]),
        },
        "technology_owner_progression_facts": catalogue._technology_facts(generated),
        "captured_maximum_level_bindings": None,
    }


def main(repo: Path, reference_root: Path, output: Path) -> None:
    sys.path.insert(0, str(repo / "tools" / "mir5"))
    import recover_modern_catalogue as catalogue

    reference_root = reference_root.resolve(strict=True)
    manifest = reference_root / "artifact-manifest.json"
    published = json.loads((reference_root / "published-reference.json").read_text(encoding="utf-8"))
    recovery = {
        "schema": 1,
        "kind": "MIR5RemainingIntegrationsF200RecoveryScratchV1",
        "status": "independently-regenerated-from-verified-reference",
        "artifact_manifest_sha256": sha256(manifest),
        "published_source": {
            "source": published["source"],
            "archive_sha256": published["sha256"],
            "tag": published["tag"],
        },
        "profiles": [
            recover_profile(
                catalogue,
                identifier,
                reference_root / "capture" / identifier / "upstream",
                reference_root / "capture" / identifier / "published",
            )
            for identifier in PROFILES
        ],
        "generation": {
            "reference_run": 40051640723,
            "inputs": "verified upstream and published F200 data/settings captures only",
            "candidate_output_used": False,
            "extractor": "tools/mir5/recover_modern_catalogue.py recovery primitives",
        },
    }
    if output.exists():
        raise FileExistsError(f"preserve existing output: {output}")
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(recovery, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(output), "sha256": sha256(output), "profiles": len(PROFILES)}, sort_keys=True))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--reference-run-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    main(args.repo.resolve(strict=True), args.reference_run_root, args.output)
