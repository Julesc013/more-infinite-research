"""Compare one MIR5 remaining-integrations candidate against frozen F200 evidence.

The three profiles use independent no-MIR and published-MIR 4.7 captures from
the reference run.  The comparison overlays the reviewed intended player
output on each no-MIR world, then compares the *complete* data and settings
worlds emitted by a candidate.  It deliberately retains complete rows and
field values for every mismatch.

This is a package-excluded build helper.  It does not launch Factorio, alter
the captures, or edit the shared catalogue comparator.  In particular, the
Py HighTech reference arms have the same selected archive identities in a
different order.  This helper verifies those exact identity sets while
retaining the raw ordered receipts verbatim in its result.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys
from typing import Any, Mapping


ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "tools" / "mir5"))
import recover_modern_catalogue as catalogue  # noqa: E402
import replay  # noqa: E402


PROFILES = ("armor-bobwarfare", "py-coal", "py-alienlife-hightech")
NATIVE_CREDIT_PREFIX = "mir-native-credit-"
EXPECTED_NATIVE_CREDIT_CARRIER_COUNT = 20
MISSING = object()


class ComparisonError(ValueError):
    """The supplied evidence does not meet this narrow comparison contract."""


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while block := stream.read(1024 * 1024):
            digest.update(block)
    return digest.hexdigest().upper()


def _json(path: Path, label: str) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
        raise ComparisonError(f"{label} is not valid UTF-8 JSON: {path}") from error


def _mapping(value: Any, label: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping) or not all(isinstance(key, str) for key in value):
        raise ComparisonError(f"{label} must be an object with string keys")
    return value


def _safe_path(root: Path, relative: Any, label: str) -> Path:
    if not isinstance(relative, str) or not relative:
        raise ComparisonError(f"{label} lacks a relative path")
    candidate = Path(relative)
    if candidate.is_absolute() or ".." in candidate.parts:
        raise ComparisonError(f"{label} has an unsafe relative path: {relative!r}")
    resolved_root = root.resolve()
    resolved = (root / candidate).resolve()
    if resolved != resolved_root and resolved_root not in resolved.parents:
        raise ComparisonError(f"{label} escapes its run root")
    return resolved


def _manifest_receipt(root: Path, label: str) -> dict[str, Any]:
    """Verify every received artifact without altering the manifest itself."""
    path = root / "artifact-manifest.json"
    manifest = _json(path, f"{label} artifact manifest")
    if not isinstance(manifest, list) or not manifest:
        raise ComparisonError(f"{label} artifact manifest must be a nonempty array")
    seen: set[str] = set()
    for index, raw in enumerate(manifest, 1):
        entry = _mapping(raw, f"{label} artifact manifest[{index}]")
        relative, digest, size = entry.get("path"), entry.get("sha256"), entry.get("bytes")
        if (not isinstance(relative, str) or relative in seen
                or not isinstance(digest, str) or len(digest) != 64
                or any(char not in "0123456789abcdefABCDEF" for char in digest)
                or not isinstance(size, int) or size < 0):
            raise ComparisonError(f"{label} artifact manifest[{index}] is malformed")
        seen.add(relative)
        artifact = _safe_path(root, relative, f"{label} artifact manifest[{index}]")
        if not artifact.is_file() or artifact.stat().st_size != size or _sha256(artifact) != digest.upper():
            raise ComparisonError(f"{label} artifact manifest differs: {relative}")
    return {
        "path": "artifact-manifest.json",
        "sha256": _sha256(path),
        "bytes": path.stat().st_size,
        "entries": len(manifest),
    }


def _file_receipt(path: Path) -> dict[str, Any]:
    if not path.is_file():
        raise ComparisonError(f"received file is absent: {path}")
    return {"path": path.name, "sha256": _sha256(path), "bytes": path.stat().st_size}


def _profile(recovery: Mapping[str, Any], identifier: str) -> Mapping[str, Any]:
    rows = recovery.get("profiles")
    if not isinstance(rows, list):
        raise ComparisonError("recovery profiles must be an array")
    matches = [row for row in rows if isinstance(row, Mapping) and row.get("id") == identifier]
    if len(matches) != 1:
        raise ComparisonError(f"recovery lacks one {identifier} profile")
    return matches[0]


def _archive_identity(row: Mapping[str, Any], label: str) -> tuple[str, str, str, bool | None]:
    name, version, digest = row.get("name"), row.get("version"), row.get("sha256")
    builtin = row.get("builtin")
    if (not isinstance(name, str) or not name or not isinstance(version, str) or not version
            or not isinstance(digest, str) or len(digest) != 64
            or any(character not in "0123456789abcdefABCDEF" for character in digest)
            or builtin is not None and not isinstance(builtin, bool)):
        raise ComparisonError(f"{label} has an invalid selected archive identity")
    return name, version, digest.upper(), builtin


def _archive_identities(rows: Any, label: str) -> tuple[tuple[str, str, str, bool | None], ...]:
    if not isinstance(rows, list):
        raise ComparisonError(f"{label} must be an array")
    identities = tuple(_archive_identity(_mapping(row, f"{label}[{index}]"), f"{label}[{index}]")
                       for index, row in enumerate(rows, 1))
    if len(set(identities)) != len(identities):
        raise ComparisonError(f"{label} contains duplicate selected archive identities")
    return identities


def _identity_rows(identities: tuple[tuple[str, str, str, bool | None], ...]) -> list[dict[str, Any]]:
    return [
        {"name": name, "version": version, "sha256": digest, "builtin": builtin}
        for name, version, digest, builtin in sorted(identities)
    ]


def _same_required_inputs(upstream: Mapping[str, Any], published: Mapping[str, Any],
                          candidate: Mapping[str, Any], profile: str) -> dict[str, Any]:
    """Verify all non-MIR inputs, allowing only archive loader order to differ."""
    for field in ("engine", "selection", "loaded", "profile"):
        baseline = upstream[field]
        if published[field] != baseline:
            raise ComparisonError(f"{profile} published {field} differs from upstream")
        if candidate[field] != baseline:
            raise ComparisonError(f"{profile} candidate {field} differs from upstream")

    upstream_archives = _archive_identities(upstream["selected"], f"{profile} upstream selected archives")
    published_archives = _archive_identities(published["selected"], f"{profile} published selected archives")
    candidate_archives = _archive_identities(candidate["selected"], f"{profile} candidate selected archives")
    expected = set(upstream_archives)
    if set(published_archives) != expected:
        raise ComparisonError(f"{profile} published selected archive identities differ from upstream")
    if set(candidate_archives) != expected:
        raise ComparisonError(f"{profile} candidate selected archive identities differ from upstream")
    return {
        "comparison": "equal-exact-identity-set",
        "identities": _identity_rows(upstream_archives),
        "upstream_order_equals_published": upstream_archives == published_archives,
        "upstream_order_equals_candidate": upstream_archives == candidate_archives,
        "published_order_equals_candidate": published_archives == candidate_archives,
        "note": (
            "Raw capture receipt order is retained. The comparison accepts a different order only after "
            "the complete selected archive identity sets, including hashes, are equal."
        ),
    }


def _value_at(row: Mapping[str, Any], path: tuple[str, ...]) -> tuple[bool, Any]:
    value: Any = row
    for part in path:
        if not isinstance(value, Mapping) or part not in value:
            return False, None
        value = value[part]
    return True, value


def _field_difference(expected: Mapping[str, Any], actual: Mapping[str, Any],
                      path: tuple[str, ...], actual_value: Any) -> dict[str, Any]:
    expected_present, expected_value = _value_at(expected, path)
    actual_present, checked_actual = _value_at(actual, path)
    if actual_present and not replay._same_json_value(checked_actual, actual_value):
        raise ComparisonError("comparison helper received an inconsistent changed-field value")
    return {
        "path": ".".join(path) if path else "<entire-row>",
        "expected": {"present": expected_present, "value": expected_value if expected_present else None},
        "actual": {"present": actual_present, "value": checked_actual if actual_present else None},
    }


def _complete_differences(expected: Mapping[str, Any], actual: Mapping[str, Any], domain: str) -> list[dict[str, Any]]:
    """Return all changed rows with every nested changed value and both whole rows."""
    differences: list[dict[str, Any]] = []
    for prototype_type in sorted(set(expected) | set(actual), key=replay._sort_key):
        expected_bucket = expected.get(prototype_type, {})
        actual_bucket = actual.get(prototype_type, {})
        if not isinstance(expected_bucket, Mapping) or not isinstance(actual_bucket, Mapping):
            differences.append({
                "domain": domain,
                "type": prototype_type,
                "name": "<non-object-domain>",
                "expected_row": expected_bucket,
                "actual_row": actual_bucket,
                "changed_fields": [{
                    "path": "<entire-row>",
                    "expected": {"present": prototype_type in expected, "value": expected_bucket},
                    "actual": {"present": prototype_type in actual, "value": actual_bucket},
                }],
            })
            continue
        for name in sorted(set(expected_bucket) | set(actual_bucket), key=replay._sort_key):
            before = expected_bucket.get(name, MISSING)
            after = actual_bucket.get(name, MISSING)
            if before is not MISSING and after is not MISSING and replay._same_json_value(before, after):
                continue
            if before is MISSING or after is MISSING:
                differences.append({
                    "domain": domain,
                    "type": prototype_type,
                    "name": name,
                    "expected_row": None if before is MISSING else before,
                    "actual_row": None if after is MISSING else after,
                    "changed_fields": [{
                        "path": "<entire-row>",
                        "expected": {"present": before is not MISSING, "value": None if before is MISSING else before},
                        "actual": {"present": after is not MISSING, "value": None if after is MISSING else after},
                    }],
                })
                continue
            if not isinstance(before, Mapping) or not isinstance(after, Mapping):
                raise ComparisonError(f"{domain} {prototype_type}.{name} is not a prototype object")
            changes = replay._changed_fields(before, after)
            differences.append({
                "domain": domain,
                "type": prototype_type,
                "name": name,
                "expected_row": before,
                "actual_row": after,
                "changed_fields": [_field_difference(before, after, path, value) for path, value in changes],
            })
    return differences


def _is_native_credit_carrier(row: Mapping[str, Any]) -> bool:
    return (
        row.get("type") == "technology"
        and isinstance(row.get("name"), str)
        and row["name"].startswith(NATIVE_CREDIT_PREFIX)
        and row.get("hidden") is True
        and row.get("enabled") is False
        and row.get("visible_when_disabled") is False
    )


def _difference_counts(differences: list[Mapping[str, Any]]) -> dict[str, Any]:
    by_domain: dict[str, int] = {}
    by_domain_type: dict[str, int] = {}
    field_count = 0
    additions = removals = replacements = 0
    for difference in differences:
        domain = str(difference["domain"])
        type_key = f"{domain}.{difference['type']}"
        by_domain[domain] = by_domain.get(domain, 0) + 1
        by_domain_type[type_key] = by_domain_type.get(type_key, 0) + 1
        field_count += len(difference["changed_fields"])
        if difference["expected_row"] is None:
            additions += 1
        elif difference["actual_row"] is None:
            removals += 1
        else:
            replacements += 1
    return {
        "rows": len(differences),
        "changed_fields": field_count,
        "candidate_only_rows": additions,
        "candidate_missing_rows": removals,
        "changed_existing_rows": replacements,
        "by_domain": dict(sorted(by_domain.items())),
        "by_domain_type": dict(sorted(by_domain_type.items())),
    }


def _classify(differences: list[dict[str, Any]]) -> dict[str, Any]:
    carrier_indexes: list[int] = []
    for index, difference in enumerate(differences):
        actual = difference["actual_row"]
        if (difference["expected_row"] is None and difference["domain"] == "data"
                and difference["type"] == "technology" and isinstance(actual, Mapping)
                and _is_native_credit_carrier(actual)):
            carrier_indexes.append(index)
    carrier_set = [differences[index] for index in carrier_indexes]
    unresolved_indexes = [index for index in range(len(differences)) if index not in set(carrier_indexes)]
    return {
        "native_credit_carrier_additions": {
            "disposition": "intentional-preservation-obligation",
            "note": (
                "These hidden candidate-only carrier technologies remain in complete_differences and are not "
                "accepted as equal published output. Their identity and complete rows are retained for the "
                "separate native-credit preservation obligation."
            ),
            "expected_count_per_profile": EXPECTED_NATIVE_CREDIT_CARRIER_COUNT,
            "actual_count": len(carrier_set),
            "matches_expected_count": len(carrier_set) == EXPECTED_NATIVE_CREDIT_CARRIER_COUNT,
            "difference_indexes": carrier_indexes,
            "ids": [difference["name"] for difference in carrier_set],
        },
        "unresolved_deltas": {
            "count": len(unresolved_indexes),
            "difference_indexes": unresolved_indexes,
            "note": "Every non-carrier mismatch remains a complete unresolved data/settings delta.",
        },
    }


def _capture_receipt(capture: Mapping[str, Any]) -> dict[str, Any]:
    receipt = catalogue._capture_receipt(capture)
    if capture["contains_mir"]:
        receipt["mir_archive"] = capture["published_mir"]
    return receipt


def _candidate_player_receipt(root: Path, candidate: Mapping[str, Any]) -> dict[str, Any]:
    path = root / "player.json"
    player = _mapping(_json(path, "candidate player receipt"), "candidate player receipt")
    mir = _mapping(candidate.get("published_mir"), "candidate MIR archive")
    required = ("kind", "source_root", "source_commit", "target", "target_record", "edition_record_sha256",
                "name", "version", "sha256", "bytes")
    if any(field not in player for field in required):
        raise ComparisonError("candidate player receipt lacks its package identity")
    for field in ("name", "version"):
        if player[field] != mir[field]:
            raise ComparisonError(f"candidate player receipt differs from captured MIR archive: {field}")
    if not isinstance(player["sha256"], str) or player["sha256"].upper() != mir["sha256"]:
        raise ComparisonError("candidate player receipt differs from captured MIR archive: sha256")
    return {
        "file": _file_receipt(path),
        "package": {field: player[field] for field in required},
    }


def compare(reference_root: Path, reference_run_id: str, candidate_root: Path, candidate_run_id: str,
            recovery_path: Path) -> dict[str, Any]:
    reference_root = reference_root.resolve(strict=True)
    candidate_root = candidate_root.resolve(strict=True)
    recovery_path = recovery_path.resolve(strict=True)
    recovery = _mapping(_json(recovery_path, "remaining-integrations recovery"), "remaining-integrations recovery")
    if recovery.get("kind") != "MIR5RemainingIntegrationsF200RecoveryScratchV1":
        raise ComparisonError("recovery has an unsupported kind")

    reference_manifest = _manifest_receipt(reference_root, "reference")
    candidate_manifest = _manifest_receipt(candidate_root, "candidate")
    if recovery.get("artifact_manifest_sha256") != reference_manifest["sha256"]:
        raise ComparisonError("recovery does not bind the supplied reference artifact manifest")
    published_reference_path = reference_root / "published-reference.json"
    published_reference = _mapping(_json(published_reference_path, "published reference receipt"), "published reference receipt")
    published_source = _mapping(recovery.get("published_source"), "recovery published source")
    if (published_reference.get("sha256") != published_source.get("archive_sha256")
            or published_reference.get("source") != published_source.get("source")):
        raise ComparisonError("recovery published source differs from published-reference receipt")

    profiles: list[dict[str, Any]] = []
    all_carrier_ids: set[str] = set()
    total_carrier_occurrences = 0
    total_unresolved = 0
    total_differences = 0
    for identifier in PROFILES:
        profile = _profile(recovery, identifier)
        upstream = catalogue.read_capture(reference_root / "capture" / identifier / "upstream", require_mir=False)
        published = catalogue.read_capture(reference_root / "capture" / identifier / "published", require_mir=True)
        candidate = catalogue.read_capture(candidate_root / "capture" / identifier / "candidate", require_mir=True)
        receipts = _mapping(profile.get("capture_receipts"), f"{identifier} recovery receipts")
        if catalogue._capture_receipt(upstream) != receipts.get("no_mir"):
            raise ComparisonError(f"{identifier} upstream capture differs from its recovery receipt")
        if catalogue._capture_receipt(published) != receipts.get("published_470"):
            raise ComparisonError(f"{identifier} published capture differs from its recovery receipt")
        if published["published_mir"]["sha256"] != published_source["archive_sha256"]:
            raise ComparisonError(f"{identifier} published capture has an unexpected MIR archive")

        archive_sets = _same_required_inputs(upstream, published, candidate, identifier)
        expected_data = catalogue._overlay_domain(
            upstream["raw"], catalogue._intended_domain(profile, "data"), f"{identifier} intended data")
        expected_settings = catalogue._overlay_domain(
            upstream["settings"], catalogue._intended_domain(profile, "settings"), f"{identifier} intended settings")
        differences = (_complete_differences(expected_data, candidate["raw"], "data")
                       + _complete_differences(expected_settings, candidate["settings"], "settings"))
        classification = _classify(differences)
        carrier = classification["native_credit_carrier_additions"]
        all_carrier_ids.update(carrier["ids"])
        total_carrier_occurrences += carrier["actual_count"]
        total_unresolved += classification["unresolved_deltas"]["count"]
        total_differences += len(differences)
        profiles.append({
            "id": identifier,
            "status": "equal-intended-native-output" if not differences else "different-intended-native-output",
            "capture_receipts": {
                "upstream": _capture_receipt(upstream),
                "published_470": _capture_receipt(published),
                "candidate": _capture_receipt(candidate),
            },
            "selected_archive_identity_check": archive_sets,
            "counts": _difference_counts(differences),
            "classification": classification,
            "complete_differences": differences,
        })

    candidate_player = _candidate_player_receipt(candidate_root, catalogue.read_capture(
        candidate_root / "capture" / PROFILES[0] / "candidate", require_mir=True))
    return {
        "schema": 1,
        "kind": "MIR5RemainingIntegrationsCandidateWholeOutputComparisonV1",
        "status": "equal-intended-native-output" if not total_differences else "different-intended-native-output",
        "scope": (
            "complete F200 data/settings output for the three pinned profiles; no native gameplay, menu, "
            "save, runtime, package qualification, or release qualification"
        ),
        "inputs": {
            "reference": {
                "run_id": reference_run_id,
                "artifact_manifest": reference_manifest,
                "published_reference": {
                    "file": _file_receipt(published_reference_path),
                    "receipt": dict(published_reference),
                },
                "published_source": dict(published_source),
                "recovery": {"file": _file_receipt(recovery_path), "kind": recovery["kind"]},
            },
            "candidate": {
                "run_id": candidate_run_id,
                "artifact_manifest": candidate_manifest,
                "player": candidate_player,
            },
        },
        "profiles": profiles,
        "counts": {
            "profiles": len(profiles),
            "complete_difference_occurrences": total_differences,
            "native_credit_carrier_occurrences": total_carrier_occurrences,
            "native_credit_carrier_unique_ids": sorted(all_carrier_ids),
            "native_credit_carrier_unique_id_count": len(all_carrier_ids),
            "unresolved_delta_occurrences": total_unresolved,
        },
        "limits": [
            "Carrier additions are reported in full and remain unequal to the published intended output.",
            "The selected archive identity comparison is order-insensitive only after preserving each raw ordered receipt.",
            "This comparison establishes no native gameplay or release evidence.",
        ],
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reference-run-root", type=Path, required=True)
    parser.add_argument("--reference-run-id", required=True)
    parser.add_argument("--candidate-run-root", type=Path, required=True)
    parser.add_argument("--candidate-run-id", required=True)
    parser.add_argument("--recovery", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    try:
        if args.output.exists():
            raise ComparisonError(f"preserve existing comparison output: {args.output}")
        result = compare(args.reference_run_root, args.reference_run_id,
                         args.candidate_run_root, args.candidate_run_id, args.recovery)
        args.output.parent.mkdir(parents=True, exist_ok=True)
        with args.output.open("xb") as stream:
            stream.write((json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode("utf-8"))
        print(json.dumps({
            "status": result["status"],
            "output": str(args.output.resolve()),
            "counts": result["counts"],
        }, sort_keys=True))
        return 0 if result["status"] == "equal-intended-native-output" else 1
    except (ComparisonError, catalogue.CatalogueError, replay.ReplayError, OSError, ValueError) as error:
        print(f"[mir5-remaining-integrations] {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
