return require("prototypes.diagnostics")
