return require("prototypes.streams")
