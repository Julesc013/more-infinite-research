# API Proof Points

Updated: 2026-07-02

This ledger records API claims that affect release planning. Use it to avoid turning Reddit ideas or memory into implementation assumptions.

Official Factorio API references should be rechecked before a release if the local Factorio version changes.

Latest official API docs checked on 2026-07-02: `2.1.9`. Local runtime validation evidence in `docs/test-results.md` now includes Factorio `2.1.9`.

## Verified Or Locally Proven

| Claim | Proof source | Status | Release impact |
| --- | --- | --- | --- |
| Mod zip names follow `{mod-name}_{version}` and `info.json` controls Factorio compatibility | Factorio mod structure docs | Verified | Package validation must match `info.json` and zip filename |
| `factorio_version = "2.0"` and `factorio_version = "2.1"` are separate release targets | Factorio mod structure docs | Verified | Main `v2.x` line targets Factorio `2.1.x`; legacy `v1.9.0` targets Factorio `2.0.x` |
| `gun-speed` modifiers use `ammo_category` | Factorio modifier docs plus local prototype files | Verified | Electric shooting speed must include `tesla` for Tesla weapons |
| Space Age Tesla gun/ammo/turret use `ammo_category = "tesla"` | Local Factorio `2.1.8` Space Age prototypes | Verified | Tesla turret speed is covered by `tesla`, not `electric` |
| Space Age `electric-weapons-damage-1` uses `__space-age__/graphics/technology/electric-weapons-damage.png` | Local Factorio `2.1.8` Space Age prototypes | Verified | Electric Shooting Speed can reuse the matching electric weapon damage art when Space Age is active |
| Base discharge defense uses `ammo_category = "electric"` | Local Factorio `2.1.8` base prototypes | Verified | Keep `electric` effect for discharge-defense-style equipment |
| Vanilla tank cannon fire-rate bonuses are `gun-speed` effects for `cannon-shell` on finite `weapon-shooting-speed` technologies | Local Factorio `2.1.8` base prototypes | Verified | MIR overlap handling must preserve finite vanilla `cannon-shell` speed effects |
| Base game locale does not provide every generated shooting-speed modifier string MIR needs | Local Factorio `2.1.8` base and Space Age locale files | Verified | MIR ships `flamethrower`, `electric`, and `tesla` shooting speed modifier descriptions |
| Hidden optional dependencies use the `(?)` prefix and affect load order | Factorio mod structure docs | Verified | The main line declares `(?) quality` so module productivity can see Quality module recipes when Quality is active without adding a separate version gate |
| Hidden optional official DLC dependencies can stay out of the user-facing optional list when support is opportunistic | Factorio mod structure docs plus local metadata validation | Verified | The main line declares `(?) elevated-rails` without a separate version gate; Rail productivity covers Elevated Rails support/ramp recipes when those prototypes are active |
| Quality module quality chance is stored on `ModulePrototype.effect.quality` | Factorio `ModulePrototype` and `Effect` docs plus local Quality prototypes | Verified | Quality module enrichment is prototype-stage, not a native infinite technology modifier |
| Omega Drill style content adds the Omega Drill and Space Age Omega-Tau | Factorio mod portal page plus validation fixture | Locally covered by fixture | Mining drill productivity covers `omega-drill`, `omega-tau`, and broader visible modded drill recipe outputs |
| Vanilla Space Age has infinite `processing-unit-productivity` | Local Factorio `2.1.8` Space Age prototypes | Verified | MIR skips parallel processing unit productivity in Space Age |
| Vanilla Space Age has infinite `low-density-structure-productivity` | Local Factorio `2.1.8` Space Age prototypes | Verified | MIR skips covered LDS recipes in Space Age |
| Vanilla Space Age has infinite `plastic-bar-productivity` | Local Factorio `2.1.8` Space Age prototypes | Verified | MIR skips covered plastic recipes in Space Age |
| Vanilla Space Age has infinite `rocket-fuel-productivity` | Local Factorio `2.1.8` Space Age prototypes | Verified | MIR skips covered rocket fuel recipes in Space Age |
| `NothingModifier` can display custom scripted effects in technology UI | Factorio `NothingModifier` docs | Verified | Scripted technologies should use visible `nothing` effects |
| JSON migrations can rename technology prototypes before Lua migrations run | Factorio migrations and data lifecycle docs | Verified | Removed generated technology IDs need explicit migration coverage |
| `DifficultySettings.spoil_time_modifier` is writable and bounded | Factorio `DifficultySettings` docs | Verified | Spoilage preservation can be global, bounded, and event-driven |
| `on_research_finished`, `on_research_reversed`, and `on_technology_effects_reset` exist | Factorio events docs | Verified | Scripted techs can recompute on research lifecycle changes |
| `on_tower_planted_seed` exists | Factorio events docs | Verified for Factorio `2.1.x` | Agricultural growth speed can be event-driven on the main line |
| `LuaEntity.tick_grown` is writable for plants | Factorio `LuaEntity` docs | Verified for Factorio `2.1.x` | Agricultural growth speed can shorten remaining growth time |
| Agricultural tower `owned_plants` can contain the same plant through multiple towers | Factorio `LuaEntity` docs | Verified | Existing plant rescale must dedupe plants |
| `PumpPrototype.pumping_speed` controls pump throughput per tick | Factorio `PumpPrototype` docs | Verified | High-throughput pump is a clean prototype unlock candidate |
| `FluidBox.max_pipeline_extent` is prototype-stage behavior | Factorio `FluidBox` docs | Verified | Pipeline extent belongs as a startup setting, not runtime research |
| `FluidBox.max_pipeline_extent` applies to a pipeline through the minimum extent of all fluid boxes in that pipeline | Factorio `FluidBox` docs plus runtime pipeline fixture | Verified | MIR's current pipeline multiplier is a global fluidbox prototype extension, not only a pipe-entity extension |
| `FluidBox` is used by many prototype classes, including pipes, pipe-to-ground, pumps, storage tanks, crafting machines, mining drills, generators, thrusters, and valves | Factorio `FluidBox` docs | Verified | Pipeline extent docs must warn that non-default values can affect machine/tank/thruster/modded fluid boxes |
| Technology modifier list includes cargo landing pad count, cargo bay unloading distance, and recipe productivity | Factorio modifier docs | Verified | These are native modifier candidates where supported |
| `change-recipe-productivity` is an official technology modifier type | Factorio modifier docs plus runtime fluid-productivity fixtures | Verified | Fluid-output productivity should stay native recipe productivity instead of runtime fluid scripting |
| Recipe results can be item or fluid product prototypes | Factorio `ProductPrototype` docs plus runtime fluid-productivity fixtures | Verified | Shared recipe matching can safely inspect fluid outputs as first-class recipe products |
| Thrusters expose `fuel_fluid_box` and `oxidizer_fluid_box` as `FluidBox` prototype fields | Factorio `ThrusterPrototype` docs | Verified | Pipeline extent scanning can reach thruster fluid boxes; thruster productivity remains recipe-output productivity, not thrust mutation |
| Fluid prototypes expose `icon`/`icons` fields | Factorio `FluidPrototype` docs | Verified | Fluid-output productivity streams can use fluid prototypes as icon candidates |
| `change-recipe-productivity` works cleanly for thruster fuel/oxidizer fluid-output recipes | Runtime fixture asserts exact recipe ownership and no duplicate infinite owner on Factorio `2.1.9` | Locally proven | `v2.1.0` implementation can ship if release balance/soak evidence stays clean |
| `change-recipe-productivity` works cleanly for oil/fluid-output recipes | Runtime fixture asserts oil-processing, cracking, lubricant, sulfuric-acid, and Space Age acid-neutralisation ownership on Factorio `2.1.9` | Locally proven | `v2.1.0` implementation can ship if release balance/soak evidence stays clean |

## Unknown Or Requires In-Game Test

| Claim | Required test | Target |
| --- | --- | --- |
| Changing `spoil_time_modifier` affects newly created spoilable items exactly as expected | Create spoilable items before and after research; compare spoil deadlines | v2.0.5 |
| Changing `spoil_time_modifier` affects existing belts/chests/labs/rockets/platform inventories | Use named manual save with existing stacks in each location | v2.0.5 if claiming existing-stack behavior; otherwise document limitation |
| Existing partially spoiled stacks recalculate or keep fixed spoil deadlines | Save with partially spoiled stacks before research | v2.0.5 if claiming existing-stack behavior; otherwise document limitation |
| Newly planted agricultural tower crops receive the growth-speed adjustment | Plant tower crops after research and compare `tick_grown` / observed growth time | v2.0.5 |
| Existing agricultural tower plants can be rescaled safely | Research/reverse growth tech in a large farm and dedupe owned plants | v2.1.0 unless proven small |
| Pipeline extent multiplier has acceptable balance and compatibility impact in large/modded fluid networks | Long-running saves and modpack soak with non-default multiplier values | v2.1.0 if making stronger recommendation than default `100%` |
| Factorio `2.0.x` exposes the agricultural tower events and fields needed by scripted agriculture | Validate on a Factorio `2.0.x` binary during legacy port | v1.9.0 |
| Factorio `2.0.x` supports any later current-line pump/pipeline prototype fields | Validate on a Factorio `2.0.x` binary during the matching legacy port | v1.9.x after the feature ships |

## API Links

- Mod structure: <https://lua-api.factorio.com/latest/auxiliary/mod-structure.html>
- Modifier list: <https://lua-api.factorio.com/latest/types/Modifier.html>
- `NothingModifier`: <https://lua-api.factorio.com/latest/types/NothingModifier.html>
- Migrations: <https://lua-api.factorio.com/latest/auxiliary/migrations.html>
- Data lifecycle: <https://lua-api.factorio.com/latest/auxiliary/data-lifecycle.html>
- Events: <https://lua-api.factorio.com/latest/events.html>
- `LuaEntity`: <https://lua-api.factorio.com/latest/classes/LuaEntity.html>
- `LuaItemStack`: <https://lua-api.factorio.com/latest/classes/LuaItemStack.html>
- `DifficultySettings`: <https://lua-api.factorio.com/latest/concepts/DifficultySettings.html>
- `PumpPrototype`: <https://lua-api.factorio.com/latest/prototypes/PumpPrototype.html>
- `FluidBox`: <https://lua-api.factorio.com/latest/types/FluidBox.html>
- `ThrusterPrototype`: <https://lua-api.factorio.com/latest/prototypes/ThrusterPrototype.html>
- `ProductPrototype`: <https://lua-api.factorio.com/latest/types/ProductPrototype.html>
- `FluidPrototype`: <https://lua-api.factorio.com/latest/prototypes/FluidPrototype.html>
- `LuaTechnology`: <https://lua-api.factorio.com/latest/classes/LuaTechnology.html>
- `ModulePrototype`: <https://lua-api.factorio.com/latest/prototypes/ModulePrototype.html>
- `Effect`: <https://lua-api.factorio.com/latest/types/Effect.html>
