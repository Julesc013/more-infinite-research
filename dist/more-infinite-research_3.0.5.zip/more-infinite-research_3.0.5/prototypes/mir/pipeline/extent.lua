local data_raw = require("prototypes.mir.platform.factorio.data_raw")

local P = {}

local DEFAULT_PIPELINE_EXTENT = 320
local MAX_PIPELINE_EXTENT = 4294967295

local FLUID_BOX_FIELDS = {
  fluid_box = true,
  input_fluid_box = true,
  output_fluid_box = true,
  fuel_fluid_box = true,
  oxidizer_fluid_box = true
}

local function scaled_extent(current, multiplier)
  local base = tonumber(current) or DEFAULT_PIPELINE_EXTENT
  local scaled = math.floor((base * multiplier) + 0.5)
  if scaled < 1 then return 1 end
  if scaled > MAX_PIPELINE_EXTENT then return MAX_PIPELINE_EXTENT end
  return scaled
end

local function apply_to_fluid_box(box, multiplier, seen_boxes)
  if type(box) ~= "table" then return 0 end
  if seen_boxes[box] then return 0 end
  seen_boxes[box] = true

  box.max_pipeline_extent = scaled_extent(box.max_pipeline_extent, multiplier)
  return 1
end

local function apply_to_fluid_boxes(value, multiplier, seen_boxes)
  if type(value) ~= "table" then return 0 end

  local count = 0
  for _, box in pairs(value) do
    count = count + apply_to_fluid_box(box, multiplier, seen_boxes)
  end
  return count
end

local function scan_table(value, multiplier, seen_nodes, seen_boxes)
  if type(value) ~= "table" then return 0 end
  if seen_nodes[value] then return 0 end
  seen_nodes[value] = true

  local count = 0
  for key, child in pairs(value) do
    if FLUID_BOX_FIELDS[key] then
      count = count + apply_to_fluid_box(child, multiplier, seen_boxes)
    elseif key == "fluid_boxes" then
      count = count + apply_to_fluid_boxes(child, multiplier, seen_boxes)
    elseif type(child) == "table" then
      count = count + scan_table(child, multiplier, seen_nodes, seen_boxes)
    end
  end

  return count
end

function P.apply(multiplier_override)
  local multiplier = tonumber(multiplier_override) or 1
  if multiplier == 1 then return end

  local count = 0
  local seen_nodes = {}
  local seen_boxes = {}

  for _, prototypes in pairs(data_raw.raw() or {}) do
    for _, prototype in pairs(prototypes or {}) do
      count = count + scan_table(prototype, multiplier, seen_nodes, seen_boxes)
    end
  end

  log("[more-infinite-research] Applied pipeline extent multiplier "
    .. tostring(multiplier)
    .. " to "
    .. tostring(count)
    .. " fluid boxes.")
end

return P
